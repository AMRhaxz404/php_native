<?php 
	$host		= 'localhost';
	$dbname		= 'dpw';
	$username	= 'root';
	$password 	= '';

	try {
		$db = new PDO("mysql:host={$host};dbname={$dbname}", $username, $password);

	} catch (Exception $e) {
		print_r($e->getMessage());
	}
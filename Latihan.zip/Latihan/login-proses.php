<?php 

	include 'db.php';

	$nama		= $_POST['nama'];
	$password 	= $_POST['password'];

	try {
		
		$query = $db->prepare("select * from user where nama=:nama");
		$query->bindParam(":nama", $nama);
		$query->execute();

		if ($query->rowCount() == 1 ){

			$result = $query->fetch();
			$saltedPassword = $password.$result['salt'];

			if ($result['password'] == sha1($saltedPassword)){
				echo "Selamat Datang " .$nama;
			} else{
				echo "Username atau Password Yang Anda Masukkan Salah !" ;
			}

		} else{
			echo "User Tidak Ditemukan !";
		}

	} catch (Exception $e) {
		print_r($e->getMessage());
	} ?>

	<!DOCTYPE html>
	<html>
	<head>
		<title>index</title>
	</head>
	<body>
	<a href="mahasiswa/index.php">Ingin Lanjut Ke Percobaan?</a>
	</body>
	</html>
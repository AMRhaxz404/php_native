<!DOCTYPE HTML>
<html>
    <head>
        <title>Halaman Login</title>
        <link rel="stylesheet" href="assets/login.css">
    </head>
   
    <body>
        <div class="container">
          <h1>Login</h1>
            <form action="login-proses.php" method="post">
                <label>Username</label><br>
                <input type="text" name="nama"><br>
                <label>Password</label><br>
                <input type="password" name="password"><br>
                <button>Login</button>
            </form><br>

            <font color="white"> silahkan login menggunakan <br>
            username : admin <br>
            password : password</font>

            
        </div>     
    </body>
</html>
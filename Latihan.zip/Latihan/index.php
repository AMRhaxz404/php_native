<!DOCTYPE html>
<html>
<head>
  <title>Index</title>
  <link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
  <header>
    <div class="main">
    	<ul>
	    	<li><a href="#" class="active">Home</a></li>
	    	<li><a href="#">Tutorial</a></li>
	    	<li><a href="#">Kontak</a></li>
	    	<li><a href="#">Logout</a></li>
    	</ul>
    </div>
  </header>

  <div class="title">
  	<h1>Selamat Datang ! </h1>
  	<h2>Silahkan Login Terlebih Dahulu</h2>
  	<button>
  		<a href="login.php"> Login</a>
  	</button>
  </div>



</body>
</html>
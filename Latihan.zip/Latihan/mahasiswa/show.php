<?php 

	include_once "../model/mahasiswa.php";

	$mahasiswa = new Mahasiswa;
	$data['nim']= $_GET['nim'];
	$mahasiswa = $mahasiswa->find($data);

 ?>

<!DOCTYPE html>
<html>
<head>
  <title>Index</title>
  <link rel="stylesheet" type="text/css" href="../assets/style.css">
</head>
<body>
  <header>
    <div class="main">
    	<ul>
	    	<li><a href="#" class="active">Home</a></li>
	    	<li><a href="#">Tutorial</a></li>
	    	<li><a href="#">Kontak</a></li>
	    	<li><a href="#">Logout</a></li>
    	</ul>
    </div>
  </header>

  <div class="title">
  	<h1>Selamat Datang !</h1>
  </div>

  <div class="container">
		 <div class="card mt">
		 	<table class="table" style="border: 1px solid #DAD6D6" >
		 		Detail Data <br> <br>
		 		<div class="card-title">
		 			<a href="edit.php"> Edit Data Mahasiswa</a><br>
		 		</div>	
		 		<dl>
		 			<dt>NIM</dt>
		 			<dd><?php echo $mahasiswa['nim'] ?></dd><br>
		 			<dt>Nama</dt>
		 			<dd><?php echo $mahasiswa['nama'] ?></dd><br>
		 			<dt>Angkatan</dt>
		 			<dd><?php echo $mahasiswa['angkatan'] ?></dd>
		 		</dl>
		 	</table>
		 </div>


</body>
</html>
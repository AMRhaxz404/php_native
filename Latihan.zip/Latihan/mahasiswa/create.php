<?php 
	
	include_once "../model/mahasiswa.php";

	if($_POST){
		$data['nim'] = $_POST['nim'];
		$data['nama'] = $_POST['nama'];
		$data['angkatan'] = $_POST['angkatan'];

		$mahasiswa = new Mahasiswa;
		$mahasiswa->store($data);

		header("Location: index.php");
	}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Index</title>
  <link rel="stylesheet" type="text/css" href="../assets/style.css">
</head>
<body>
  <header>
    <div class="main">
    	<ul>
	    	<li><a href="#" class="active">Home</a></li>
	    	<li><a href="#">Tutorial</a></li>
	    	<li><a href="#">Kontak</a></li>
	    	<li><a href="#">Logout</a></li>
    	</ul>
    </div>
  </header>

  <div class="title">
  	<h1>Selamat Datang !</h1>
  </div>

 <main class="container">
		<div class="card">
			<form action="" method="POST" enctype="multipart/form-data">
				<div class="form-control">
					<p class="label">NIM</p>
					<input type="text" class="input-control" name="nim">
				</div>
				<div class="form-control">
					<p class="label">Nama</p>
					<input type="text" class="input-control" name="nama">
				</div>
				<div class="form-control">
					<p class="label">Angkatan</p>
					<input type="number" class="input-control" name="angkatan">
				</div>
				<button name="simpan">Simpan</button>
				
			</form>
		</div>
	</main>

<!--   <div class="button">
  	<a href="#" class="btn">Watch Video</a>
  	<a href="#" class="btn">Learn Video</a>
  </div> -->

</body>
</html>
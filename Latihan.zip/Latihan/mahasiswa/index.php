<?php 

	include_once "../model/mahasiswa.php";

	$mahasiswa = new Mahasiswa;
	$list_data_mahasiswa = $mahasiswa->all();

 ?>

<!DOCTYPE html>
<html>
<head>
  <title>Index</title>
  <link rel="stylesheet" type="text/css" href="../assets/style.css">
</head>
<body>
  <header>
    <div class="main">
    	<ul>
	    	<li><a href="#" class="active">Home</a></li>
	    	<li><a href="#">Tutorial</a></li>
	    	<li><a href="#">Kontak</a></li>
	    	<li><a href="../login.php">Logout</a></li>
    	</ul>
    </div>
  </header>

  <div class="title">
  	<h1>Selamat Datang !</h1>
  </div>

  <div class="container">
		 <div class="card mt">
		 	<table class="table" style="border: 1px solid #DAD6D6" >
		 		Data
		 		<div class="card-title">
		 			<a href="create.php"> Tambah Data Mahasiswa</a>
		 		</div>	
		 		<thead>
		 			<tr>
		 				<th>No</th>
		 				<th>NIM</th>
		 				<th>Nama</th>
		 				<th>Angkatan</th>
		 				<th width="200px">Aksi</th>
		 			</tr>
		 		</thead>
		 		<tbody>
		 			<?php foreach ($list_data_mahasiswa as $key => $mahasiswa):  ?>
		 				<tr>
		 					<td><?php echo $key+1 ?></td>
		 					<td><?php echo $mahasiswa['nim'] ?></td>
		 					<td><?php echo $mahasiswa['nama'] ?></td>
		 					<td><?php echo $mahasiswa['angkatan'] ?></td>
		 					<td>
		 						<a href="edit.php?nim=<?php echo $mahasiswa['nim'] ?>"> <font color="yellow">Edit</a></font>
		 						<a href="show.php?nim=<?php echo $mahasiswa['nim'] ?>"><font color="blue">Detail</a></font>
		 						<a onclick="return confirm('Yakin Ingin Menghapus Data Ini?')" href="delete.php?nim=<?php echo $mahasiswa['nim'] ?>"><font color="red">Delete</a></font>
		 					</td>
		 				</tr>
		 			<?php endforeach ?>
		 		</tbody>
		 	</table>
		 </div>


</body>
</html>
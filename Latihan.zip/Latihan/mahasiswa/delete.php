<?php 

	include_once "../model/mahasiswa.php";

	$mahasiswa = new Mahasiswa;
	$data['nim']= $_GET['nim'];
	$mahasiswa->delete($data);

	header("location: index.php");
 ?>